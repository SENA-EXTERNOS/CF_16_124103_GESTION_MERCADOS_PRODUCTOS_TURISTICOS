function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6RdsXaCGpJG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

